

<?php $__env->startSection('title', '| Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text">
        PRODUK
    </div>
    <div class="card m-4 mt-0">
        <div class="card-header p-0">
            <h3 class="primary-text primary-bg text-cont p-2 m-0 border">Daftar Produk</h3>
        </div>
        <div class="card-body">
            <table id="tableProduk" class="table table-striped table-hover table-bordered">
                <colgroup>
                    <col style="width: 10%;">
                    <col style="width: 35%;">
                    <col style="width: 20%;">
                    <col style="width: 25%;">
                    <col style="width: 10%">
                </colgroup>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Penyedia Produk</th>
                        <th>Stok</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="/produk/<?php echo e($product->productCode); ?>"><?php echo e($product->productCode); ?></a></td>
                        <td><a href="/produk/<?php echo e($product->productCode); ?>"><?php echo e($product->productName); ?></a></td>
                        <td><a href="/produk/<?php echo e($product->productCode); ?>"><?php echo e($product->productLine); ?></a></td>
                        <td><a href="/produk/<?php echo e($product->productCode); ?>"><?php echo e($product->productVendor); ?></a></td>
                        <td><a href="/produk/<?php echo e($product->productCode); ?>"><?php echo e($product->quantityInStock); ?></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="card-footer p-0">
            <p class="primary-text primary-bg text-cont p-2 mb-0 border"></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum8\resources\views/produk.blade.php ENDPATH**/ ?>