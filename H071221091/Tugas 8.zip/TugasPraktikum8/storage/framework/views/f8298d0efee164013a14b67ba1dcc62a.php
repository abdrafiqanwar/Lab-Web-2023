

<?php $__env->startSection('title', '| Kantor'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text">
        KANTOR
    </div>
    <div class="card m-4 mt-1">
        <div class="card-header p-0">
            <h3 class="primary-text primary-bg text-cont p-2 m-0 border rounded-top">Daftar Kantor</h3>
        </div>
        <div class="card-body">
            <table id="tableKantor" class="table table-striped table-hover table-bordered">
                <colgroup>
                    <col style="width: 2%;">
                    <col style="width: 15%;">
                    <col style="width: 23%;">
                    <col style="width: 30%;">
                    <col style="width: 15%;">
                    <col style="width: 15%;">
                </colgroup>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kota</th>
                        <th>no. Telpon</th>
                        <th>Alamat</th>
                        <th>Negara</th>
                        <th>Kode Pos</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($office->officeCode); ?> </td>
                        <td> <?php echo e($office->city); ?> </td>
                        <td> <?php echo e($office->phone); ?> </td>
                        <td> <?php echo $office->alamat_lengkap; ?> </td>
                        <td> <?php echo e($office->country); ?> </td>
                        <td> <?php echo e($office->postalCode); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="card-footer p-0">
            <p class="primary-text primary-bg text-cont p-2 m-0 border rounded-bottom"></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum8\resources\views/kantor.blade.php ENDPATH**/ ?>