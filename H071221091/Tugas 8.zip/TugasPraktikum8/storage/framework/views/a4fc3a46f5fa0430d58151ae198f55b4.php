

<?php $__env->startSection('title', '| Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text">
        DETAIL PRODUK : <?php echo e($products->productName); ?>

    </div>
    <div class="container-fluid">
        <div id="carouselExampleAutoplaying" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo e(asset('/assets/img/'.$products->productLine.'/1.jpg')); ?>" class="d-block mx-auto" alt="..."
                        style="height: auto; max-height: 100%;">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('/assets/img/'.$products->productLine.'/2.jpg')); ?>" class="d-block mx-auto" alt="..."
                        style="height: auto; max-height: 100%;">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('/assets/img/'.$products->productLine.'/3.jpg')); ?>" class="d-block mx-auto" alt="..."
                        style="height: auto; max-height: 100%;">
                </div>
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <div class="container box-all mt-4">
        <div class="box-produk">
            <div>
                <h5>Kode Produk     : <span> <?php echo e($products->productCode); ?> </span></h5>
                <h5>Nama Produk     : <span> <?php echo e($products->productName); ?> </span></h5>
                <h5>Kategori Produk : <span> <?php echo e($products->productLine); ?> </span></h5>
                <h5>Penydia produk  : <span> <?php echo e($products->productVendor); ?> </span></h5>
            </div>
            <div>
                <h5>Skala Produksi  : <span> <?php echo e($products->productScale); ?> </span></h5>
                <h5>Stok Produk  : <span> <?php echo e($products->quantityInStock); ?> </span></h5>
                <h5>Harga Satuan : <span> $<?php echo e($products->buyPrice); ?></h5>
            </div>
        </div>
        <div class="box-desk">
            <h5>Deskripsi Produk</h5>
            <p> <span> <?php echo e($products->productDescription); ?> </span> </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum8\resources\views/detail-produk.blade.php ENDPATH**/ ?>