

<?php $__env->startSection('title', '| Karyawan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text">
        KARYAWAN
    </div>
    <div class="card m-4 mt-1">
        <div class="card-header p-0">
            <h3 class="primary-text primary-bg text-cont p-2 m-0 border rounded-top">Daftar Karyawan</h3>
        </div>
        <div class="card-body">
            <table id="tableKaryawan" class="table table-striped table-hover table-bordered">
                <colgroup>
                    <col style="width: 5%;">
                    <col style="width: 25%;">
                    <col style="width: 30%;">
                    <col style="width: 20%;">
                    <col style="width: 20%;">
                </colgroup>
                <thead>
                    <tr>
                        <th>no. Karyawan</th>
                        <th>Nama Lengkap</th>
                        <th>Email</th>
                        <th>Jabatan</th>
                        <th>Kantor (kota)</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($employee->employeeNumber); ?> </td>
                        <td> <?php echo e($employee->full_name); ?> </td>
                        <td> <?php echo e($employee->email); ?> </td>
                        <td> <?php echo e($employee->jobTitle); ?> </td>
                        <td> <?php echo e($employee->cityByOfficeCode->city); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="card-footer p-0">
            <p class="primary-text primary-bg text-cont p-2 m-0 border rounded-bottom"></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum8\resources\views/karyawan.blade.php ENDPATH**/ ?>